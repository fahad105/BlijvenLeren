﻿using BlijvenLeren.Data;
using BlijvenLeren.Models;
using Microsoft.EntityFrameworkCore;

namespace BlijvenLeren.Services
{
    public class LearningResourceService : ILearningResourceService
    {

        private readonly ApplicationDbContext _context;

        public LearningResourceService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<LearningResource>> GetAllLearningResources()
        {
            return await _context.LearningResources.ToListAsync();
        }

        public async Task<LearningResource> GetLearningResource(int id)
        {
            return await _context.LearningResources.FindAsync(id);
        }

        public async Task CreateLearningResource(LearningResource learningResource)
        {
            _context.LearningResources.Add(learningResource);
            await _context.SaveChangesAsync();
        }

        public async Task<LearningResource> UpdateLearningResource(int id, LearningResource learningResource)
        {
            var dbLearningResource = await _context.LearningResources.FindAsync(id);
            if (dbLearningResource == null)
            {
                return null;
            }

            dbLearningResource.Title = learningResource.Title;
            dbLearningResource.Description = learningResource.Description;
            dbLearningResource.Url = learningResource.Url;
            
            await _context.SaveChangesAsync();
            return dbLearningResource;
        }

        public async Task DeleteLearningResource(LearningResource learningResource)
        {
            _context.LearningResources.Remove(learningResource);
            await _context.SaveChangesAsync();
        }
    }
}
