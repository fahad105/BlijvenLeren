﻿using BlijvenLeren.Models;

namespace BlijvenLeren.Services
{
    public interface ILearningResourceService
    {
        public Task<IEnumerable<LearningResource>> GetAllLearningResources();
        public Task<LearningResource> GetLearningResource(int id);

        public Task CreateLearningResource(LearningResource learningResource);
        public Task<LearningResource> UpdateLearningResource(int id, LearningResource learningResource);
        public Task DeleteLearningResource(LearningResource learningResource);

    }
}
