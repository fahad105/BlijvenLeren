﻿using BlijvenLeren.Models;
using BlijvenLeren.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BlijvenLeren.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("[controller]")]
    public class LearningResourceController : ControllerBase
    {
        private readonly ILearningResourceService _learningResourceService;

        public LearningResourceController(ILearningResourceService learningResourceService)
        {
            _learningResourceService = learningResourceService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<LearningResource>>> GetAllLearningResources()
        {
            return Ok(await _learningResourceService.GetAllLearningResources());
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateLearningResource(int id, LearningResource learningResource)
        {
            if (id != learningResource.Id)
            {
                return BadRequest();
            }

            var updatedLearningResource = await _learningResourceService.UpdateLearningResource(id, learningResource);
            if (updatedLearningResource == null)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpPost("create")]
        public async Task<ActionResult<LearningResource>> CreateLearningResource(LearningResource learningResource)
        {
            await _learningResourceService.CreateLearningResource(learningResource);
            return CreatedAtAction("GetLearningResource", new { id = learningResource.Id }, learningResource);
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteLearningResource(int id)
        {
            var learningResource = await _learningResourceService.GetLearningResource(id);
            if (learningResource == null)
            {
                return NotFound();
            }

            await _learningResourceService.DeleteLearningResource(learningResource);
            return NoContent();
        }
    }
}
