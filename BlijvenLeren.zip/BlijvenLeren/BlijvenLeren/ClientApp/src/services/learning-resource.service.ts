import { Injectable } from '@angular/core';
import { LearningResource } from 'src/models/learning-resource.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LearningResourceService {

  private http!: HttpClient;

  constructor(http: HttpClient) {
    this.http = http;
  }

  async getLearningResources(): Promise<LearningResource[]> {
    return await this.http.get<LearningResource[]>("https://localhost:7202/LearningResource", 
    {
      headers: new HttpHeaders({'Access-Control-Allow-Origin':'*'})
    }).toPromise();
  }

}
