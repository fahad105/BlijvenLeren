import { Component, Inject } from '@angular/core';
import { LearningResource } from 'src/models/learning-resource.model';
import { LearningResourceService } from 'src/services/learning-resource.service';

@Component({
  selector: 'app-learning-resource',
  templateUrl: './learning-resource.component.html'
})
export class LearningResourceComponent {
  public learningResources: LearningResource[] = [];
  private service:LearningResourceService;

  constructor(service: LearningResourceService) {
    this.service = service;
    this.service.getLearningResources();
  };
}


