﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BlijvenLeren.Data.Migrations
{
    public partial class AddIsInternalToApplicationUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsInternal",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsInternal",
                table: "AspNetUsers");
        }
    }
}
