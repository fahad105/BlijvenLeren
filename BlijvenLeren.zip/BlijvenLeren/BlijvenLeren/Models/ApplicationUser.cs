﻿using Microsoft.AspNetCore.Identity;

namespace BlijvenLeren.Models
{
    public class ApplicationUser : IdentityUser
    {
        public bool IsInternal { get; set; }
    }
}